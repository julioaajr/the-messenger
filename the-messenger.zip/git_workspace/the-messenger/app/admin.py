from django.contrib import admin
from .models import Amizade, Amigos

# Register your models here.
admin.site.register(Amizade)
admin.site.register(Amigos)