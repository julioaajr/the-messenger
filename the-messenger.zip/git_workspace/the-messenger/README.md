# the-messenger



1- Justificativa
    Necessidade é a comunicação entre pessoas que tenham confiança entre elas evitando a propagação de fake news criando dessa forma uma rede confiável de informações.

2- finalidade
    enviar mensagens para 1 ou mais pessoas.

3- objetivo
    desenvolver e aplicar conhecimento adquirido em aula para completar o projeto

4- descrição do produto
    criar o login

5- estimativa de tempo
    2 horas e 30 para desenvolvimento.

6- não é escopo
    o sistema não vai enviar imagens, nem permitir integração com outros sistemas.

7- criterios de aceitação
    enviar mensagens somente para pessoas com login

8- premissa restrições e riscos
    falta de conhecimento, falta de tempo